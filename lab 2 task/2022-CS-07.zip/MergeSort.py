"""    Problem 3   """
# Merge Function
def Merge(array, l, m, h):
    B = [0] * (h+1)
    i = l
    j = m+1
    k = l
    while i <= m and j <= h:
        if array[i] < array[j]:
            B[k] = array[i]
            k += 1
            i += 1
        else:
            B[k] = array[j]
            k += 1
            j += 1
    while i <= m:
        B[k] = array[i]
        k += 1
        i += 1
    while j <=h:
        B[k] = array[j]
        k += 1
        j += 1
    for a in range(1,h+1):
        array[a] = B[a]
        
#MergeSort Using Recursive Approach       
def MergeSort(array, l, h):
    if l < h:
        mid = int((l+h)/2)
        MergeSort(array, l, mid)
        MergeSort(array, mid+1, h)
        Merge(array, l, mid, h)
    print(array)

#Main Function
A = [15,13,7,12,16,9,3,21]
MergeSort(A, 0, 7)

